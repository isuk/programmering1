
def volCalc(length, height, width):
    print(f"The volume of your object is: {length * height * width} (cm3)")

print("Volume Calculator (cm)")
length = int(input("Length "))
height = int(input("Height: "))
width = int(input("Width: "))

volCalc(length, height, width)
