import random

def randNum():
    print("====")
    print(f"={random.randint(0, 101)}=")
    print("====")

randNum()
