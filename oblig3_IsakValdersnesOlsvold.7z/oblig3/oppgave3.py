def printListContent(userInput):
    for content in userInput:
        print(content)

favArtists = ["Death Grips", "Kent", "Parannoul", "Giles Corey", "[KRTM]", "Bjarki"]

printListContent(favArtists)
