
for num in range(9, 102, 2):
    print(num)

unevenList = list(range(1, 102, 2))
print(unevenList)


n = 1

while n <= 101:
    if n % 2 != 0:
        print(n)
    n += 1
